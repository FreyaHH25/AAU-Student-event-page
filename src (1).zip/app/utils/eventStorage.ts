export interface Event {
  id: string;
  title: string;
  description: string;
  category: string;
  organizer: string;
  date: string; // YYYY-MM-DD format
  startTime: string;
  endTime: string;
  location: string;
  visibility: string;
  imageUrl: string;
  attendees: number;
  categoryColor: string;
  semester: string; // "All" or "1st Semester" through "8th Semester"
}

const STORAGE_KEY = 'aau_events';
const ATTENDING_KEY = 'aau_attending_events';

// Get category color based on category
export function getCategoryColor(category: string): string {
  const colorMap: { [key: string]: string } = {
    music: 'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300',
    sports: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
    academic: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
    social: 'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300',
    cultural: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
    workshop: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
    conference: 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300',
  };
  return colorMap[category.toLowerCase()] || 'bg-gray-100 text-gray-700 dark:bg-gray-900 dark:text-gray-300';
}

// Get all events from localStorage
export function getEvents(): Event[] {
  if (typeof window === 'undefined') return [];
  
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return [];
  
  try {
    return JSON.parse(stored);
  } catch {
    return [];
  }
}

// Save events to localStorage
export function saveEvents(events: Event[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(events));
}

// Add a new event
export function addEvent(event: Omit<Event, 'id' | 'attendees' | 'categoryColor'>): Event {
  const events = getEvents();
  const newEvent: Event = {
    ...event,
    id: Date.now().toString(),
    attendees: 0,
    categoryColor: getCategoryColor(event.category),
  };
  
  events.push(newEvent);
  saveEvents(events);
  
  return newEvent;
}

// Sort events by date
export function sortEventsByDate(events: Event[]): Event[] {
  return [...events].sort((a, b) => {
    const dateA = new Date(a.date + ' ' + a.startTime);
    const dateB = new Date(b.date + ' ' + b.startTime);
    return dateA.getTime() - dateB.getTime();
  });
}

// Format date for display
export function formatEventDate(dateStr: string): string {
  const date = new Date(dateStr);
  const options: Intl.DateTimeFormatOptions = { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  };
  return date.toLocaleDateString('en-US', options);
}

// Format time for display
export function formatEventTime(startTime: string, endTime: string): string {
  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };
  
  if (endTime) {
    return `${formatTime(startTime)} - ${formatTime(endTime)}`;
  }
  return formatTime(startTime);
}

// Get attending events
export function getAttendingEvents(): string[] {
  if (typeof window === 'undefined') return [];
  
  const stored = localStorage.getItem(ATTENDING_KEY);
  if (!stored) return [];
  
  try {
    return JSON.parse(stored);
  } catch {
    return [];
  }
}

// Save attending events
function saveAttendingEvents(eventIds: string[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(ATTENDING_KEY, JSON.stringify(eventIds));
}

// Check if user is attending an event
export function isAttending(eventId: string): boolean {
  const attendingEvents = getAttendingEvents();
  return attendingEvents.includes(eventId);
}

// Toggle attending status for an event
const ALL_ATTENDEES_KEY = 'aau_all_event_attendees';

// 1. Function to get the list of names for a specific event
export function getEventAttendeeNames(eventId: string): string[] {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem(ALL_ATTENDEES_KEY);
  if (!stored) return [];
  try {
    const data = JSON.parse(stored);
    return data[eventId] || [];
  } catch {
    return [];
  }
}

// 2. Helper to save names to the global list
function saveAllAttendeeNames(eventId: string, names: string[]): void {
  if (typeof window === 'undefined') return;
  const stored = localStorage.getItem(ALL_ATTENDEES_KEY);
  const data = stored ? JSON.parse(stored) : {};
  data[eventId] = names;
  localStorage.setItem(ALL_ATTENDEES_KEY, JSON.stringify(data));
}

// 3. NEW toggle function that handles names
export function toggleAttending(eventId: string, userName: string = 'Student'): boolean {
  const attendingEvents = getAttendingEvents();
  const globalNames = getEventAttendeeNames(eventId);
  const index = attendingEvents.indexOf(eventId);
  let isNowAttending: boolean;

  if (index > -1) {
    // Remove
    attendingEvents.splice(index, 1);
    const updatedNames = globalNames.filter(name => name !== userName);
    saveAllAttendeeNames(eventId, updatedNames);
    isNowAttending = false;
  } else {
    // Add
    attendingEvents.push(eventId);
    if (!globalNames.includes(userName)) {
      globalNames.push(userName);
      saveAllAttendeeNames(eventId, globalNames);
    }
    isNowAttending = true;
  }

  saveAttendingEvents(attendingEvents);
  window.dispatchEvent(new CustomEvent('attendingChanged'));
  return isNowAttending;
} 

// Delete an event
export function deleteEvent(eventId: string): void {
  const events = getEvents();
  const filteredEvents = events.filter(event => event.id !== eventId);
  saveEvents(filteredEvents);
  
  // Also remove from attending list if present
  const attendingEvents = getAttendingEvents();
  const attendingIndex = attendingEvents.indexOf(eventId);
  if (attendingIndex > -1) {
    attendingEvents.splice(attendingIndex, 1);
    saveAttendingEvents(attendingEvents);
  }
  
  // Dispatch event to notify components
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('eventDeleted'));
  }
}