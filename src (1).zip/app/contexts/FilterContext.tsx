import React, { createContext, useContext, useState, useEffect } from 'react';

interface FilterContextType {
  selectedCategories: string[];
  setSelectedCategories: React.Dispatch<React.SetStateAction<string[]>>;
  selectedSemesters: string[];
  setSelectedSemesters: React.Dispatch<React.SetStateAction<string[]>>;
  searchQuery: string;
  setSearchQuery: React.Dispatch<React.SetStateAction<string[]>>;
}

const FilterContext = createContext<FilterContextType | undefined>(undefined);

export function FilterProvider({ children }: { children: React.ReactNode }) {
  // We initialize from localStorage so it even survives a page refresh!
  const [selectedCategories, setSelectedCategories] = useState<string[]>(() => {
    const saved = localStorage.getItem('global_categories');
    return saved ? JSON.parse(saved) : [];
  });

  const [selectedSemesters, setSelectedSemesters] = useState<string[]>(() => {
    const saved = localStorage.getItem('global_semesters');
    return saved ? JSON.parse(saved) : [];
  });

  const [searchQuery, setSearchQuery] = useState('');

  // Save to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('global_categories', JSON.stringify(selectedCategories));
  }, [selectedCategories]);

  useEffect(() => {
    localStorage.setItem('global_semesters', JSON.stringify(selectedSemesters));
  }, [selectedSemesters]);

  return (
    <FilterContext.Provider value={{ 
      selectedCategories, setSelectedCategories, 
      selectedSemesters, setSelectedSemesters,
      searchQuery, setSearchQuery 
    }}>
      {children}
    </FilterContext.Provider>
  );
}

export const useFilters = () => {
  const context = useContext(FilterContext);
  if (!context) throw new Error('useFilters must be used within a FilterProvider');
  return context;
};