import { X, Calendar, Clock, MapPin, Users, Info, ExternalLink } from 'lucide-react';
import { Event } from '../utils/eventStorage';

interface EventDetailPanelProps {
  event: Event | null;
  onClose: () => void;
}

export function EventDetailPanel({ event, onClose }: EventDetailPanelProps) {
  if (!event) return null;

  return (
    <div className="fixed inset-0 z-[100] flex justify-end bg-black/40 backdrop-blur-sm transition-opacity">
      {/* Click outside to close */}
      <div className="absolute inset-0" onClick={onClose} />
      
      <div 
        className="relative w-full max-w-md h-full bg-white dark:bg-gray-900 shadow-2xl animate-in slide-in-from-right duration-300 flex flex-col"
      >
        {/* Header Image */}
        <div className="relative h-56 w-full flex-shrink-0">
          <img 
            src={event.imageUrl} 
            alt={event.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-black/20 hover:bg-white/20 rounded-full text-white backdrop-blur-md transition-all border border-white/10"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="absolute bottom-4 left-6">
            <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${event.categoryColor || 'bg-blue-100 text-blue-700'}`}>
              {event.category}
            </span>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white leading-tight">
              {event.title}
            </h2>
            <p className="mt-2 text-gray-600 dark:text-gray-400">
              Hosted by <span className="font-semibold text-blue-600 dark:text-blue-400">{event.organizer}</span>
            </p>
          </div>

          {/* Quick Info Grid */}
          <div className="grid grid-cols-1 gap-4 py-6 border-y border-gray-100 dark:border-gray-800">
            <div className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
              <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded-lg">
                <Calendar className="w-5 h-5 text-blue-500" />
              </div>
              <span className="font-medium">
                {new Date(event.date).toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  month: 'long', 
                  day: 'numeric',
                  year: 'numeric' 
                })}
              </span>
            </div>
            
            <div className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
              <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded-lg">
                <Clock className="w-5 h-5 text-blue-500" />
              </div>
              <span className="font-medium">{event.startTime} - {event.endTime}</span>
            </div>

            <div className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
              <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded-lg">
                <MapPin className="w-5 h-5 text-blue-500" />
              </div>
              <span className="font-medium">{event.location}</span>
            </div>

            <div className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
              <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded-lg">
                <Users className="w-5 h-5 text-blue-500" />
              </div>
              <span className="font-medium">{event.attendees} students attending</span>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-bold text-gray-900 dark:text-white uppercase tracking-wider">
              <Info className="w-4 h-4 text-blue-500" />
              Description
            </div>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              {event.description}
            </p>
          </div>

          {/* Target Audience */}
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-900/30">
            <p className="text-sm text-blue-800 dark:text-blue-300">
              <span className="font-bold">Target Audience:</span> This event is primarily for students in their <span className="font-bold">{event.semester}</span>.
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-6 bg-gray-50 dark:bg-gray-900/50 border-t border-gray-100 dark:border-gray-800">
          <button className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2">
            Register for Event
            <ExternalLink className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}