import { Settings, LogOut } from 'lucide-react';
import { useEffect, useRef } from 'react';

interface ProfileDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
  onProfileSettings: () => void;
}

export function ProfileDropdown({ isOpen, onClose, onLogout, onProfileSettings }: ProfileDropdownProps) {
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      ref={dropdownRef}
      className="absolute top-full right-0 mt-2 w-56 bg-white dark:bg-gray-900 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden z-50"
    >
      {/* Profile Settings */}
      <button
        onClick={() => {
          onProfileSettings();
          onClose();
        }}
        className="w-full flex items-center gap-3 px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
      >
        <Settings className="w-5 h-5 text-gray-600 dark:text-gray-400" />
        <span className="font-medium">Profile Settings</span>
      </button>

      {/* Divider */}
      <div className="border-t border-gray-100 dark:border-gray-800"></div>

      {/* Logout */}
      <button
        onClick={() => {
          onLogout();
          onClose();
        }}
        className="w-full flex items-center gap-3 px-4 py-3 text-red-600 dark:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
      >
        <LogOut className="w-5 h-5" />
        <span className="font-medium">Logout</span>
      </button>
    </div>
  );
}
