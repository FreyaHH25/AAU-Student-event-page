import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useRef, useState, useEffect } from 'react';
import { EventCard } from './EventCard';
import { formatEventDate, formatEventTime } from '../utils/eventStorage';

interface Event {
  id: string;
  image?: string;
  imageUrl?: string;
  category: string;
  title: string;
  description: string;
  date: string;
  time?: string;
  startTime?: string;
  endTime?: string;
  location: string;
  attendees: number;
  organizer: string;
  categoryColor?: string;
}

interface EventSectionProps {
  title: string;
  count?: number;
  events: Event[];
  onEventClick?: (event: Event) => void;
}

export function EventSection({ title, count, events, onEventClick }: EventSectionProps) {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const [isHovered, setIsHovered] = useState(false);

  const checkScroll = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setCanScrollLeft(scrollLeft > 5);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 5);
    }
  };

  useEffect(() => {
    checkScroll();
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', checkScroll);
      window.addEventListener('resize', checkScroll);
      
      // Initial check after render
      setTimeout(checkScroll, 100);
      
      return () => {
        container.removeEventListener('scroll', checkScroll);
        window.removeEventListener('resize', checkScroll);
      };
    }
  }, [events]);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const cardWidth = scrollContainerRef.current.querySelector('div')?.offsetWidth || 280;
      const scrollAmount = cardWidth + 20; // card width + gap
      const currentScroll = scrollContainerRef.current.scrollLeft;
      const newScrollLeft = direction === 'left'
        ? currentScroll - scrollAmount
        : currentScroll + scrollAmount;
      
      scrollContainerRef.current.scrollTo({
        left: newScrollLeft,
        behavior: 'smooth'
      });
      
      // Recheck after scroll animation
      setTimeout(checkScroll, 350);
    }
  };

  return (
    <div className="mb-10">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-1 h-6 bg-orange-500 rounded-full"></div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            {title}
            {count !== undefined && (
              <span className="ml-2 text-sm font-normal text-gray-500 dark:text-gray-400">({count})</span>
            )}
          </h2>
        </div>
      </div>

      {/* Events Container with Hover Navigation */}
      <div 
        className="relative"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Left Arrow - appears on hover */}
        {events.length > 4 && isHovered && canScrollLeft && (
          <button
            onClick={() => scroll('left')}
            className="absolute left-2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-white dark:bg-gray-800 shadow-lg flex items-center justify-center hover:bg-gray-50 dark:hover:bg-gray-700 transition-all"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-5 h-5 text-gray-700 dark:text-gray-300" />
          </button>
        )}

        {/* Right Arrow - appears on hover */}
        {events.length > 4 && isHovered && canScrollRight && (
          <button
            onClick={() => scroll('right')}
            className="absolute right-2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-white dark:bg-gray-800 shadow-lg flex items-center justify-center hover:bg-gray-50 dark:hover:bg-gray-700 transition-all"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-5 h-5 text-gray-700 dark:text-gray-300" />
          </button>
        )}

        {/* Events Container */}
        <div
          ref={scrollContainerRef}
          className="flex gap-5 overflow-x-auto pb-2"
          style={{ 
            scrollbarWidth: 'none',
            msOverflowStyle: 'none'
          }}
        >
          {events.map((event) => (
            <EventCard 
              key={event.id} 
              {...event} 
              onClick={() => onEventClick?.(event)} 
            />
          ))}
        </div>
      </div>
      
      <style>{`
        div::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
}