import { X, Calendar, MapPin, Users, GraduationCap } from 'lucide-react';
import { useEffect, useState } from 'react';
import { getEvents, Event } from '../utils/eventStorage';

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  userSemester?: string;
  onNotificationDismiss: (eventId: string) => void;
  dismissedNotifications: string[];
}

export function NotificationPanel({ 
  isOpen, 
  onClose, 
  userSemester = '3rd Semester',
  onNotificationDismiss,
  dismissedNotifications 
}: NotificationPanelProps) {
  const [events, setEvents] = useState<Event[]>([]);

  useEffect(() => {
    const loadEvents = () => {
      const allEvents = getEvents();
      setEvents(allEvents);
    };
    
    loadEvents();
    
    // Listen for new events
    const handleEventCreated = () => {
      loadEvents();
    };
    
    window.addEventListener('eventCreated', handleEventCreated);
    
    return () => {
      window.removeEventListener('eventCreated', handleEventCreated);
    };
  }, []);

  // Filter university events (organized by university departments)
  const universityEvents = events.filter(event => {
    const isUniversityEvent = 
      event.organizer?.toLowerCase().includes('university') ||
      event.organizer?.toLowerCase().includes('administration') ||
      event.organizer?.toLowerCase().includes('aau');
    
    return isUniversityEvent && !dismissedNotifications.includes(event.id);
  });

  // Filter semester-specific events
  const semesterEvents = events.filter(event => {
    const matchesSemester = event.semester === userSemester;
    const notDismissed = !dismissedNotifications.includes(event.id);
    const notUniversityEvent = !universityEvents.find(e => e.id === event.id);
    
    return matchesSemester && notDismissed && notUniversityEvent;
  });

  const totalNotifications = universityEvents.length + semesterEvents.length;

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="fixed top-[88px] right-6 w-[480px] max-h-[calc(100vh-120px)] bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 z-50 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Notifications</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {totalNotifications} new {totalNotifications === 1 ? 'update' : 'updates'}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-400 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {totalNotifications === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-gray-400" />
              </div>
              <p className="text-gray-600 dark:text-gray-400">No new notifications</p>
              <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                You'll be notified about university events and events for your semester
              </p>
            </div>
          ) : (
            <>
              {/* University Events Section */}
              {universityEvents.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <GraduationCap className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    <h3 className="font-semibold text-gray-900 dark:text-white">University Events</h3>
                    <span className="px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 text-xs font-medium rounded-full">
                      {universityEvents.length}
                    </span>
                  </div>
                  
                  <div className="space-y-3">
                    {universityEvents.map(event => (
                      <NotificationCard
                        key={event.id}
                        event={event}
                        onDismiss={() => onNotificationDismiss(event.id)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Semester Events Section */}
              {semesterEvents.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <GraduationCap className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                    <h3 className="font-semibold text-gray-900 dark:text-white">Your Semester Events</h3>
                    <span className="px-2 py-0.5 bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-400 text-xs font-medium rounded-full">
                      {semesterEvents.length}
                    </span>
                  </div>
                  
                  <div className="space-y-3">
                    {semesterEvents.map(event => (
                      <NotificationCard
                        key={event.id}
                        event={event}
                        onDismiss={() => onNotificationDismiss(event.id)}
                      />
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
}

interface NotificationCardProps {
  event: Event;
  onDismiss: () => void;
}

function NotificationCard({ event, onDismiss }: NotificationCardProps) {
  const formatDateTime = (date: string, startTime?: string, endTime?: string) => {
    const eventDate = new Date(date + 'T00:00:00');
    const dateStr = eventDate.toLocaleDateString('en-US', { 
      weekday: 'long', 
      month: 'long', 
      day: 'numeric',
      year: 'numeric'
    });
    
    if (startTime) {
      const timeStr = endTime 
        ? `${startTime} - ${endTime}`
        : `at ${startTime}`;
      return `${dateStr} ${timeStr}`;
    }
    
    return dateStr;
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 border border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 transition-colors">
      <div className="flex items-start justify-between gap-3 mb-3">
        <h4 className="font-semibold text-gray-900 dark:text-white flex-1">
          {event.title}
        </h4>
        <button
          onClick={onDismiss}
          className="p-1 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400 transition-colors flex-shrink-0"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
      
      <div className="space-y-2 text-sm">
        {/* Date & Time */}
        <div className="flex items-start gap-2 text-gray-600 dark:text-gray-400">
          <Calendar className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <span>{formatDateTime(event.date, event.startTime, event.endTime)}</span>
        </div>
        
        {/* Location */}
        {event.location && (
          <div className="flex items-start gap-2 text-gray-600 dark:text-gray-400">
            <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>{event.location}</span>
          </div>
        )}
        
        {/* Attendees */}
        <div className="flex items-start gap-2 text-gray-600 dark:text-gray-400">
          <Users className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <span>{event.attendees} attending</span>
        </div>
        
        {/* Organizer */}
        <div className="text-xs text-gray-500 dark:text-gray-500 mt-2">
          Organized by {event.organizer}
        </div>
      </div>
    </div>
  );
}