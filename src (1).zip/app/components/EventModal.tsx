import { X, Calendar, MapPin, Users, Clock, Trash2, UserCheck, GraduationCap, ChevronDown, ChevronUp } from 'lucide-react';
import { Badge } from './ui/badge';
import { useState, useEffect } from 'react';
import { isAttending, toggleAttending, formatEventDate, getEventAttendeeNames } from '../utils/eventStorage';

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  event: {
    id: string;
    image?: string;
    imageUrl?: string;
    category: string;
    title: string;
    description: string;
    date: string;
    displayDate?: string;
    time?: string;
    startTime?: string;
    endTime?: string;
    location: string;
    attendees: number;
    organizer: string;
    categoryColor?: string;
    semester?: string;
  } | null;
  canDelete?: boolean;
  onDelete?: (eventId: string) => void;
  isLoggedIn?: boolean;
  user?: { 
  name: string; 
  email: string; 
  semester?: string; // We added this
} | null;
}

export function EventModal({ isOpen, onClose, event, canDelete, onDelete, isLoggedIn, user }: EventModalProps) {
  const [attending, setAttending] = useState(false);
  const [showAttendeeList, setShowAttendeeList] = useState(false); // ADDED THIS

  
 // This ensures the list refreshes every time the 'attending' state or the event changes
const [attendeeNames, setAttendeeNames] = useState<string[]>([]);

useEffect(() => {
  if (event) {
    setAttendeeNames(getEventAttendeeNames(event.id));
  }
}, [event, attending]); // List refreshes when you click the button!

  useEffect(() => {
    if (event) {
      setAttending(isAttending(event.id));
    }
  }, [event]);

  if (!isOpen || !event) return null;

  const displayImage = event.image || event.imageUrl || 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400&h=300&fit=crop';

  const displayAttendees = attending ? (event.attendees || 0) + 1 : (event.attendees || 0);
  
  // Calculate display attendees count
const handleAttendClick = () => {
  // 1. Get the profile from localStorage
  const savedProfile = localStorage.getItem('userProfile');
  
  // 2. Set default fallbacks if nothing is found
  let finalName = "User";
  let finalRole = "Student";
  let finalSem = "";

  if (savedProfile) {
    const profile = JSON.parse(savedProfile);
    
    // MATCHING THE KEYS:
    // profileName in State -> name in Storage
    // currentSemester in State -> semester in Storage
    finalName = profile.name || "User";
    finalRole = profile.role || "Student";
    finalSem = profile.semester ? ` - ${profile.semester}` : "";
  }

  // 3. Construct the full string: "Student Knyaz, V - 2rd Semester"
  const fullIdentifier = `${finalRole} ${finalName}${finalSem}`;

  // 4. Toggle attendance
  const newAttendingStatus = toggleAttending(event.id, fullIdentifier); 
  setAttending(newAttendingStatus);
  
  // 5. Refresh the list
  window.dispatchEvent(new Event('attendingChanged'));
};

  const handleDeleteClick = () => {
    if (onDelete) {
      onDelete(event.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-white/90 dark:bg-gray-900/90 hover:bg-white dark:hover:bg-gray-900 rounded-full transition-colors"
        >
          <X className="w-5 h-5 text-gray-700 dark:text-gray-300" />
        </button>

        {/* Event Image */}
        <div className="relative h-64 overflow-hidden rounded-t-2xl">
          <img 
            src={displayImage} 
            alt={event.title}
            className="w-full h-full object-cover"
          />
          <Badge className={`absolute top-4 left-4 ${event.categoryColor} border-0 px-3 py-1.5`}>
            {event.category}
          </Badge>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Title */}
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            {event.title}
          </h2>

          {/* Description */}
          <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
            {event.description}
          </p>

          {/* Event Details */}
          <div className="space-y-4 mb-6">
            {/* Date & Time */}
            <div className="flex items-start gap-3">
              <Calendar className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
              <div>
                <div className="font-medium text-gray-900 dark:text-white">{event.displayDate || formatEventDate(event.date)}</div>
                {event.time && (
                  <div className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-1.5 mt-1">
                    <Clock className="w-4 h-4" />
                    {event.time}
                  </div>
                )}
              </div>
            </div>

            {/* Location */}
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
              <div>
                <div className="font-medium text-gray-900 dark:text-white">Location</div>
                <div className="text-sm text-gray-600 dark:text-gray-400 mt-0.5">{event.location}</div>
              </div>
            </div>

      {/* Attendees */}
<div className="flex items-start gap-3">
  <Users className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
  <div className="flex-1">
    {/* Clickable Header */}
    <button 
      onClick={() => setShowAttendeeList(!showAttendeeList)}
      className="flex items-center gap-2 group hover:text-blue-600 transition-colors"
    >
      <div className="font-medium text-gray-900 dark:text-white group-hover:text-blue-600">
        {displayAttendees} attending
      </div>
      {showAttendeeList ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
    </button>
    
    <div className="text-sm text-gray-600 dark:text-gray-400 mt-0.5">
      Organized by {event.organizer}
    </div>

    {/* Expanded List of Names */}
    {showAttendeeList && (
      <div className="mt-3 p-3 bg-gray-50 dark:bg-gray-900/50 rounded-xl border border-gray-100 dark:border-gray-700 max-h-40 overflow-y-auto">
        <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">Confirmed Guests</p>
        <div className="space-y-2 max-h-[160px] overflow-y-auto pr-2 custom-scrollbar">
          {attendeeNames.length > 0 ? (
            attendeeNames.map((name, index) => (
              <div 
                key={index} 
                className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 bg-black/5 dark:bg-white/5 p-2 rounded-lg border border-transparent hover:border-blue-500/30 transition-all"
              >
                <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]" />
                <span className="font-medium">{name}</span>
              </div>
            ))
          ) : (
            <div className="py-4 text-center">
              <p className="text-sm text-gray-400 italic">No guests confirmed yet.</p>
            </div>
          )}
        </div>
      </div>
    )}
  </div> {/* This closes the flex-1 div */}
</div> {/* This closes the flex container */}

            {/* Semester */}
            {event.semester && (
              <div className="flex items-start gap-3">
                <GraduationCap className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                <div>
                  <div className="font-medium text-gray-900 dark:text-white">Semester</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400 mt-0.5">{event.semester}</div>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            {isLoggedIn && (
              <button
                onClick={handleAttendClick}
                className={`flex-1 px-6 py-3 rounded-lg font-medium transition-colors ${
                  attending
                    ? 'bg-green-600 hover:bg-green-700 text-white'
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
              >
                {attending ? 'Attending ✓' : 'Attend Event'}
              </button>
            )}
            {canDelete && (
              <button
                onClick={handleDeleteClick}
                className="px-6 py-3 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium transition-colors flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Delete
              </button>
            )}
            <button
              onClick={onClose}
              className="px-6 py-3 rounded-lg border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}