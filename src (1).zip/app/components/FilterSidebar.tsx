import { X, Check } from 'lucide-react';

interface FilterSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  selectedCategories: string[];
  onCategoryToggle: (category: string) => void;
  onShowAll: () => void;
  selectedSemesters: string[];
  onSemesterToggle: (semester: string) => void;
  onShowAllSemesters: () => void;
}

const categories = [
  { id: 'all', label: 'Show All', color: 'bg-gray-500' },
  { id: 'workshop', label: 'Workshop', color: 'bg-blue-500' },
  { id: 'academic', label: 'Academic', color: 'bg-purple-500' },
  { id: 'sports', label: 'Sports', color: 'bg-green-500' },
  { id: 'music', label: 'Music', color: 'bg-pink-500' },
  { id: 'social', label: 'Social', color: 'bg-orange-500' },
  { id: 'cultural', label: 'Cultural', color: 'bg-yellow-500' },
  { id: 'tech', label: 'Technology', color: 'bg-indigo-500' },
  { id: 'art', label: 'Art & Design', color: 'bg-red-500' },
  { id: 'networking', label: 'Networking', color: 'bg-teal-500' },
];

const semesters = [
  { id: 'all', label: 'All Semesters' },
    { id: '1st Semester', label: '1st Semester' },
  { id: '2nd Semester', label: '2nd Semester' },
  { id: '3rd Semester', label: '3rd Semester' },
  { id: '4th Semester', label: '4th Semester' },
  { id: '5th Semester', label: '5th Semester' },
  { id: '6th Semester', label: '6th Semester' },
  { id: '7th Semester', label: '7th Semester' },
  { id: '8th Semester', label: '8th Semester' },
];

export function FilterSidebar({ 
  isOpen, 
  onClose, 
  selectedCategories, 
  onCategoryToggle, 
  onShowAll,
  selectedSemesters,
  onSemesterToggle,
  onShowAllSemesters
}: FilterSidebarProps) {
  const isAllCategoriesSelected = selectedCategories.length === 0;
  const isAllSemestersSelected = selectedSemesters.length === 0;

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40 transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-full w-80 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 shadow-2xl z-50 transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-200 dark:border-gray-800">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Filters</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-400 transition-colors"
            aria-label="Close filters"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto h-[calc(100%-80px)]">
          {/* Category Section */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-4 uppercase tracking-wide">
              Event Categories
            </h3>
            <div className="space-y-2">
              {categories.map((category) => {
                const isSelected = category.id === 'all' 
                  ? isAllCategoriesSelected 
                  : selectedCategories.includes(category.id);

                return (
                  <button
                    key={category.id}
                    onClick={() => {
                      if (category.id === 'all') {
                        onShowAll();
                      } else {
                        onCategoryToggle(category.id);
                      }
                    }}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-all ${
                      isSelected
                        ? 'bg-gray-900 dark:bg-gray-800 text-white shadow-md'
                        : 'bg-gray-50 dark:bg-gray-800/50 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-3 h-3 rounded-full ${category.color}`}
                      />
                      <span className="font-medium text-sm">{category.label}</span>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Filters Count */}
          {!isAllCategoriesSelected && (
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {selectedCategories.length} {selectedCategories.length === 1 ? 'filter' : 'filters'} active
                </span>
                <button
                  onClick={onShowAll}
                  className="text-sm text-blue-600 dark:text-blue-400 hover:underline font-medium"
                >
                  Clear all
                </button>
              </div>
            </div>
          )}

          {/* Semester Section */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-4 uppercase tracking-wide">
              Event Semesters
            </h3>
            <div className="space-y-2">
              {semesters.map((semester) => {
                const isSelected = semester.id === 'all' 
                  ? isAllSemestersSelected 
                  : selectedSemesters.includes(semester.id);

                return (
                  <button
                    key={semester.id}
                    onClick={() => {
                      if (semester.id === 'all') {
                        onShowAllSemesters();
                      } else {
                        onSemesterToggle(semester.id);
                      }
                    }}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-all ${
                      isSelected
                        ? 'bg-gray-900 dark:bg-gray-800 text-white shadow-md'
                        : 'bg-gray-50 dark:bg-gray-800/50 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-medium text-sm">{semester.label}</span>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Filters Count */}
          {!isAllSemestersSelected && (
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {selectedSemesters.length} {selectedSemesters.length === 1 ? 'filter' : 'filters'} active
                </span>
                <button
                  onClick={onShowAllSemesters}
                  className="text-sm text-blue-600 dark:text-blue-400 hover:underline font-medium"
                >
                  Clear all
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}