import { MapPin, Users, Calendar } from 'lucide-react';
import { Badge } from './ui/badge';
import { formatEventDate, formatEventTime, isAttending } from '../utils/eventStorage';

interface EventCardProps {
  id: string;
  image?: string;
  imageUrl?: string;
  category: string;
  title: string;
  description: string;
  date: string;
  displayDate?: string;
  time?: string;
  startTime?: string;
  endTime?: string;
  location: string;
  attendees: number;
  organizer: string;
  categoryColor?: string;
  onClick?: () => void;
}

export function EventCard({
  id,
  image,
  imageUrl,
  category,
  title,
  description,
  date,
  displayDate,
  time,
  startTime,
  endTime,
  location,
  attendees,
  organizer,
  categoryColor = 'bg-purple-100 text-purple-700',
  onClick
}: EventCardProps) {
  // Use imageUrl if image is not provided (for backward compatibility)
  const displayImage = image || imageUrl || 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400&h=300&fit=crop';
  
  // Format date and time if we have startTime/endTime
  const finalDisplayDate = displayDate || (date.includes(',') ? date : formatEventDate(date));
  const displayTime = time || (startTime ? formatEventTime(startTime, endTime || '') : '');

  // Check if user is attending and calculate display count
  const userIsAttending = isAttending(id);
  const displayAttendees = userIsAttending ? attendees + 1 : attendees;

  return (
    <div 
      className="flex-shrink-0 w-[calc(25%-15px)] min-w-[280px] bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer border border-gray-100 dark:border-gray-700"
      onClick={onClick}
    >
      {/* Image */}
      <div className="relative h-[200px] overflow-hidden">
        <img 
          src={displayImage} 
          alt={title}
          className="w-full h-full object-cover"
        />
        <Badge className={`absolute top-3 left-3 ${categoryColor} border-0 text-sm px-3 py-1.5 rounded-full font-medium`}>
          {category}
        </Badge>
      </div>

      {/* Content */}
      <div className="p-5">
        {/* Title */}
        <h3 className="font-bold text-xl text-gray-900 dark:text-white mb-2 line-clamp-2">
          {title}
        </h3>
        
        {/* Description */}
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-5 line-clamp-2 leading-relaxed">
          {description}
        </p>

        {/* Date & Time */}
        <div className="flex items-start gap-2.5 mb-3">
          <Calendar className="w-5 h-5 text-gray-400 dark:text-gray-500 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <div className="font-semibold text-gray-900 dark:text-white text-sm">
              {finalDisplayDate}
            </div>
            {displayTime && (
              <div className="text-sm text-gray-500 dark:text-gray-500 mt-0.5">
                {displayTime}
              </div>
            )}
          </div>
        </div>

        {/* Location */}
        <div className="flex items-center gap-2.5 mb-4">
          <MapPin className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
          <span className="text-sm text-gray-900 dark:text-white line-clamp-1 font-medium">
            {location}
          </span>
        </div>

        {/* Attendees */}
        <div className="flex items-center gap-2.5 mb-4">
          <Users className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
          <span className="text-sm font-semibold text-gray-900 dark:text-white">
            {displayAttendees} attending
          </span>
        </div>

        {/* Organizer */}
        <div className="text-sm text-gray-500 dark:text-gray-500">
          Organized by <span className="font-semibold text-gray-900 dark:text-white">{organizer}</span>
        </div>
      </div>
    </div>
  );
}