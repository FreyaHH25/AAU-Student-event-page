import { Bell, Moon, Sun, LogIn } from 'lucide-react';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Link } from 'react-router';
import { useState, useEffect } from 'react';
import logoImg from 'figma:asset/e2fc18099503e16491aa44047e60c2b1d3868991.png';
import uniEventsLogo from 'figma:asset/db2b7d8782cbadb861e96d642d54dda33a99c270.png';
import { ProfileDropdown } from './ProfileDropdown';
import { ProfileSettingsModal } from './ProfileSettingsModal';

interface HeaderProps {
  isLoggedIn: boolean;
  onLoginClick: () => void;
  onLogout: () => void;
  isDarkMode: boolean;
  onThemeToggle: () => void;
  notificationCount: number;
  activePage?: 'events' | 'calendar' | 'create-event';
  onNotificationClick?: () => void;
}

export function Header({ isLoggedIn, onLoginClick, onLogout, isDarkMode, onThemeToggle, notificationCount, activePage, onNotificationClick }: HeaderProps) {
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [isProfileSettingsOpen, setIsProfileSettingsOpen] = useState(false);
  const [profileImageUrl, setProfileImageUrl] = useState('https://i.redd.it/isks98mi86a71.jpg');

  // Load profile image from localStorage
  useEffect(() => {
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      const profile = JSON.parse(savedProfile);
      if (profile.imageUrl) {
        setProfileImageUrl(profile.imageUrl);
      }
    }
  }, []);

  // Listen for profile updates
  useEffect(() => {
    const handleProfileUpdate = (event: any) => {
      if (event.detail?.imageUrl) {
        setProfileImageUrl(event.detail.imageUrl);
      }
    };

    window.addEventListener('profileUpdated', handleProfileUpdate);
    return () => window.removeEventListener('profileUpdated', handleProfileUpdate);
  }, []);

  const handleProfileSettings = () => {
    setIsProfileSettingsOpen(true);
  };

  return (
    <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
      <div className="container mx-auto px-6 py-6">
        <div className="flex items-center justify-between mb-6">
          {/* Logo - Much Bigger */}
          <div className="flex items-center gap-3">
            <img src={logoImg} alt="AAU" className="h-[120px] object-contain" />
            <span className="font-bold text-3xl dark:text-white">AAU</span>
          </div>

          {/* Center - UniEvents Logo - Bigger */}
          <div className="absolute left-1/2 -translate-x-1/2">
            <img src={uniEventsLogo} alt="UniEvents" className="h-16 object-contain" />
          </div>

          {/* Right side */}
          <div className="flex items-center gap-3">
            {isLoggedIn ? (
              <>
                {/* Theme Toggle */}
                <button
                  onClick={onThemeToggle}
                  className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                  aria-label="Toggle theme"
                >
                  {isDarkMode ? (
                    <Sun className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  ) : (
                    <Moon className="w-5 h-5 text-gray-600" />
                  )}
                </button>

                {/* Notification */}
                <button className="relative p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800" onClick={onNotificationClick}>
                  <Bell className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  {notificationCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
                  )}
                </button>

                {/* Profile */}
                <div className="relative">
                  <Avatar 
                    className="w-25 h-25 cursor-pointer" 
                    onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                  >
                    <AvatarImage src={profileImageUrl} alt="Profile" />
                    <AvatarFallback>ME</AvatarFallback>
                  </Avatar>
                  <ProfileDropdown
                    isOpen={isProfileDropdownOpen}
                    onClose={() => setIsProfileDropdownOpen(false)}
                    onProfileSettings={handleProfileSettings}
                    onLogout={onLogout}
                  />
                </div>
              </>
            ) : (
              <button onClick={onLoginClick} className="flex items-center gap-2 px-6 py-2.5 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-full text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors shadow-sm">
                <LogIn className="w-5 h-5" />
                <span className="text-base font-medium">Login</span>
              </button>
            )}
          </div>
        </div>

        {/* Navigation Pills - Centered */}
        <nav className="flex items-center justify-center gap-2">
          <Link to="/events">
            <button className={`px-5 py-2 rounded-full ${activePage === 'events' ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900' : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-400'} text-sm font-medium`}>
              Events
            </button>
          </Link>
          <Link to="/calendar">
            <button className={`px-5 py-2 rounded-full ${activePage === 'calendar' ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900' : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-400'} text-sm font-medium`}>
              Calendar
            </button>
          </Link>
          <Link to="/create-event">
            <button className={`px-5 py-2 rounded-full ${activePage === 'create-event' ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900' : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-400'} text-sm font-medium`}>
              CreateEvent
            </button>
          </Link>
        </nav>
      </div>
      <ProfileSettingsModal
        isOpen={isProfileSettingsOpen}
        onClose={() => setIsProfileSettingsOpen(false)}
      />
    </header>
  );
}