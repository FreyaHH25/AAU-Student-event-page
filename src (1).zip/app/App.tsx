import { RouterProvider } from "react-router";
import { router } from './routes';
import { AuthProvider } from './contexts/AuthContext';
import { FilterProvider } from './contexts/FilterContext'; // 1. Import the new provider
import '../styles/index.css';

function App() {
  return (
    <AuthProvider>
      <FilterProvider> 
        <RouterProvider router={router} />
      </FilterProvider>
    </AuthProvider>
  );
}

export default App;