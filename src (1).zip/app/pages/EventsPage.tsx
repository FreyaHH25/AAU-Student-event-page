import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { EventSection } from '../components/EventSection';
import { EventModal } from '../components/EventModal';
import { LoginModal } from '../components/LoginModal';
import { FilterSidebar } from '../components/FilterSidebar';
import { NotificationPanel } from '../components/NotificationPanel';
import { getEvents, Event, getAttendingEvents, deleteEvent } from '../utils/eventStorage';
import { Search, SlidersHorizontal } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useFilters } from '../contexts/FilterContext';

export function EventsPage() {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // Initialize from localStorage
    const saved = localStorage.getItem('isDarkMode');
    return saved === 'true';
  });
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const { 
  selectedCategories, setSelectedCategories, 
  selectedSemesters, setSelectedSemesters, 
  searchQuery, setSearchQuery
} = useFilters();
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [dismissedNotifications, setDismissedNotifications] = useState<string[]>(() => {
    const saved = localStorage.getItem('dismissedNotifications');
    return saved ? JSON.parse(saved) : [];
  });
  const [userSemester] = useState(() => {
    const saved = localStorage.getItem('userSemester');
    return saved || '3rd Semester';
  });
  const notificationCount = 1;

  // Load events from storage
  const [userEvents, setUserEvents] = useState<Event[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Persist login state to localStorage
  const { user, logout } = useAuth();
  const isLoggedIn = !!user; // This replaces your old state variable
  // Persist dark mode to localStorage
  useEffect(() => {
    localStorage.setItem('isDarkMode', String(isDarkMode));
  }, [isDarkMode]);

  useEffect(() => {
    // Load events when component mounts or refreshKey changes
    const loadEvents = () => {
      const events = getEvents();
      setUserEvents(events);
    };
    
    loadEvents();
  }, [refreshKey]);

  // Listen for custom event that signals new event was created or attending changed
  useEffect(() => {
    const handleEventCreated = () => {
      setRefreshKey(prev => prev + 1);
    };

    const handleAttendingChanged = () => {
      setRefreshKey(prev => prev + 1);
    };
    
    window.addEventListener('eventCreated', handleEventCreated);
    window.addEventListener('attendingChanged', handleAttendingChanged);
    
    return () => {
      window.removeEventListener('eventCreated', handleEventCreated);
      window.removeEventListener('attendingChanged', handleAttendingChanged);
    };
  }, []);

  // Apply dark mode to document
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Sample events data (original events)
  const sampleEvents = [
    {
      id: '1',
      image: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=300&fit=crop',
      category: 'Workshop',
      title: 'Study Group - Finals Preparation',
      description: 'Join fellow students for collaborative studying and exam preparation',
      date: '2026-03-15',
      startTime: '19:00',
      endTime: '21:00',
      location: 'University Library, Room 302',
      attendees: 24,
      organizer: 'Academic Success Center',
      categoryColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      semester: 'All'
    },
    {
      id: '9',
      image: 'https://www.en.aau.dk/media/qwjblkut/aau-studiestart-2023-billeder.jpg',
      category: 'Academic',
      title: 'University Open Day 2026',
      description: 'Annual university-wide open day showcasing all programs and facilities',
      date: '2026-04-05',
      startTime: '09:00',
      endTime: '16:00',
      location: 'Main Campus',
      attendees: 450,
      organizer: 'University Administration',
      categoryColor: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
      semester: 'All'
    },
    {
      id: '10',
      image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&h=300&fit=crop',
      category: 'Conference',
      title: 'Career Fair - Tech Companies',
      description: 'Meet recruiters from leading technology companies',
      date: '2026-04-22',
      startTime: '10:00',
      endTime: '18:00',
      location: 'Exhibition Hall',
      attendees: 380,
      organizer: 'Career Services',
      categoryColor: 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300',
      semester: 'All'
    },
    {
      id: '4',
      image: 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=400&h=300&fit=crop',
      category: 'Workshop',
      title: 'Resume Writing Workshop',
      description: 'Learn how to craft an impressive resume and cover letter',
      date: '2026-03-27',
      startTime: '16:00',
      endTime: '18:00',
      location: 'Career Center, Suite 200',
      attendees: 18,
      organizer: 'Career Services',
      categoryColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      semester: '3rd Semester'
    },
    {
      id: '5',
      image: 'https://www.aaudxp-cms.aau.dk/media/bxfhffxv/studiestart_esbjerg_24-1200px.jpg',
      category: 'Sports',
      title: 'Basketball Tournament Finals',
      description: 'Championship game of the annual intramural basketball tournament',
      date: '2026-03-29',
      startTime: '19:00',
      endTime: '21:00',
      location: 'Recreation Center',
      attendees: 156,
      organizer: 'Athletics Department',
      categoryColor: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
      semester: 'All'
    },
    {
      id: '6',
      image: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400&h=300&fit=crop',
      category: 'Academic',
      title: 'Guest Lecture: AI in Healthcare',
      description: 'Renowned researcher discusses applications of AI in medical diagnostics',
      date: '2026-04-02',
      startTime: '15:00',
      endTime: '17:00',
      location: 'Science Building, Auditorium A',
      attendees: 89,
      organizer: 'Computer Science Department',
      categoryColor: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
      semester: '5th Semester'
    },
    {
      id: '7',
      image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&h=300&fit=crop',
      category: 'Social',
      title: 'International Food Festival',
      description: 'Celebrate global cultures with authentic cuisines from around the world',
      date: '2026-04-06',
      startTime: '12:00',
      endTime: '18:00',
      location: 'Student Union Plaza',
      attendees: 245,
      organizer: 'International Student Association',
      categoryColor: 'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300',
      semester: 'All'
    },
    {
      id: '8',
      image: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=400&h=300&fit=crop',
      category: 'Workshop',
      title: 'Photography Basics Workshop',
      description: 'Hands-on introduction to photography techniques and composition',
      date: '2026-04-11',
      startTime: '17:00',
      endTime: '19:00',
      location: 'Arts Building, Studio 5',
      attendees: 22,
      organizer: 'Photography Club',
      categoryColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      semester: '1st Semester'
    },
    {
      id: '2',
      image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=400&h=300&fit=crop',
      category: 'Conference',
      title: 'Engineering Club Meeting',
      description: 'Monthly meeting to discuss upcoming projects and research collaboration',
      date: '2026-04-12',
      startTime: '18:00',
      endTime: '20:00',
      location: 'Engineering Building, LAB 18',
      attendees: 45,
      organizer: 'Engineering Society',
      categoryColor: 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300',
      semester: '2nd Semester'
    },
    {
      id: '3',
      image: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=400&h=300&fit=crop',
      category: 'Social',
      title: 'Spring Festival 2026',
      description: 'Annual spring celebration with food, music, and entertainment',
      date: '2026-04-20',
      startTime: '14:00',
      endTime: '22:00',
      location: 'Main Campus Quad',
      attendees: 320,
      organizer: 'Student Activities Board',
      categoryColor: 'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300',
      semester: 'All'
    },
    {
      id: '11',
      image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop',
      category: 'Workshop',
      title: 'UI/UX Design Sprint',
      description: 'A fast-paced workshop on prototyping user interfaces using modern design tools.',
      date: '2026-03-25',
      startTime: '10:00',
      endTime: '13:00',
      location: 'Design Lab, Room 104',
      attendees: 15,
      organizer: 'Digital Arts Collective',
      categoryColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      semester: 'All'
    },
    {
      id: '12',
      image: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?w=400&h=300&fit=crop',
      category: 'Sports',
      title: 'Mid-Week Yoga Flow',
      description: 'De-stress with a guided yoga session open to all skill levels.',
      date: '2026-03-25',
      startTime: '08:00',
      endTime: '09:00',
      location: 'South Campus Lawn',
      attendees: 42,
      organizer: 'Wellness Center',
      categoryColor: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
      semester: 'All'
    },
    {
      id: '13',
      image: 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=400&h=300&fit=crop',
      category: 'Academic',
      title: 'Sustainability Symposium',
      description: 'Discussing renewable energy initiatives within the university infrastructure.',
      date: '2026-03-25',
      startTime: '14:00',
      endTime: '16:30',
      location: 'Green Hall, Auditorium C',
      attendees: 120,
      organizer: 'Environmental Society',
      categoryColor: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
      semester: 'All'
    },
    {
      id: '14',
      image: 'https://images.unsplash.com/photo-1528605248644-14dd04022da1?w=400&h=300&fit=crop',
      category: 'Social',
      title: 'Board Game Night',
      description: 'Pizza, tabletop games, and networking with fellow students.',
      date: '2026-03-25',
      startTime: '18:00',
      endTime: '21:00',
      location: 'Student Lounge',
      attendees: 55,
      organizer: 'Gaming Club',
      categoryColor: 'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300',
      semester: '1st Semester'
    },
    {
      id: '15',
      image: 'https://images.unsplash.com/photo-1431540015161-0bf868a2d407?w=400&h=300&fit=crop',
      category: 'Conference',
      title: 'Startup Networking Mixer',
      description: 'Connect with local entrepreneurs and discuss internship opportunities.',
      date: '2026-03-25',
      startTime: '17:00',
      endTime: '19:00',
      location: 'Innovation Hub',
      attendees: 85,
      organizer: 'Business School',
      categoryColor: 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300',
      semester: 'All'
    }
  ];

  // Helper functions for formatting dates and times
  const formatEventDate = (dateString: string) => {
    const date = new Date(dateString + 'T00:00:00');
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatEventTime = (startTime?: string, endTime?: string) => {
    if (!startTime) return '';
    if (!endTime) return startTime;
    return `${startTime} - ${endTime}`;
  };

  const sortEventsByDate = (events: any[]) => {
    return [...events].sort((a, b) => {
      const dateA = new Date(a.date + 'T00:00:00');
      const dateB = new Date(b.date + 'T00:00:00');
      return dateA.getTime() - dateB.getTime();
    });
  };

  // Format user-created events to match the display format
  const formattedUserEvents = userEvents.map(event => ({
    id: event.id,
    image: event.imageUrl,
    imageUrl: event.imageUrl,
    category: event.category,
    title: event.title,
    description: event.description,
    date: event.date, // Keep YYYY-MM-DD for sorting
    displayDate: formatEventDate(event.date),
    time: formatEventTime(event.startTime, event.endTime),
    startTime: event.startTime,
    endTime: event.endTime,
    location: event.location,
    attendees: event.attendees,
    organizer: event.organizer,
    categoryColor: event.categoryColor,
    semester: event.semester || 'All'
  }));

  // Format sample events to match display format
  const formattedSampleEvents = sampleEvents.map(event => ({
    ...event,
    displayDate: formatEventDate(event.date),
    time: formatEventTime(event.startTime, event.endTime)
  }));

  // Combine sample events with user-created events
  const allEvents = [...formattedSampleEvents, ...formattedUserEvents];

  // Create a "My Events" section with only user-created events
  const myEvents = formattedUserEvents;

  // Get events I'm attending
  const attendingEventIds = getAttendingEvents();
  const attendingEvents = allEvents.filter(event => attendingEventIds.includes(event.id));

  // Handle event click
  const handleEventClick = (event: any) => {
    setSelectedEvent(event);
    setIsModalOpen(true);
  };

  // Handle event delete
  const handleEventDelete = (eventId: string) => {
    if (window.confirm('Are you sure you want to delete this event?')) {
      deleteEvent(eventId);
      setRefreshKey(prev => prev + 1);
    }
  };

  // Check if the selected event can be deleted (user created it)
  const canDeleteSelectedEvent = selectedEvent ? 
    userEvents.some(event => event.id === selectedEvent.id) : false;



  // Handle notification dismiss
  const handleNotificationDismiss = (eventId: string) => {
    const updated = [...dismissedNotifications, eventId];
    setDismissedNotifications(updated);
    localStorage.setItem('dismissedNotifications', JSON.stringify(updated));
  };

  // Filter events based on selected categories and semesters
 const filterEvents = (events: any[]) => {
    let filtered = events;
    
    // 1. Filter by search text
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(event => 
        event.title.toLowerCase().includes(query) || 
        event.description.toLowerCase().includes(query) ||
        event.location.toLowerCase().includes(query)
      );
    }
    
    // 2. Filter by category
    if (selectedCategories.length > 0) {
      filtered = filtered.filter(event => 
        selectedCategories.includes(event.category.toLowerCase())
      );
    }
    
    // 3. Filter by semester
    if (selectedSemesters.length > 0) {
      filtered = filtered.filter(event => {
        const eventSemester = event.semester || 'All';
        return selectedSemesters.includes(eventSemester);
      });
    }
    
    return filtered;
  };

  // Apply filters to event lists
  const filteredAllEvents = filterEvents(allEvents);
  const filteredPopularEvents = filterEvents(allEvents)
    .sort((a, b) => b.attendees - a.attendees) // Sort by attendees (most first)
    .slice(0, 6); // Take top 6 most popular
  const filteredMyEvents = filterEvents(myEvents);
  const filteredAttendingEvents = filterEvents(attendingEvents);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <Header
        isLoggedIn={isLoggedIn}
        onLoginClick={() => {}}
        onLogout={logout}
        isDarkMode={isDarkMode}
        onThemeToggle={() => setIsDarkMode(!isDarkMode)}
        notificationCount={notificationCount}
        activePage="events"
        onNotificationClick={() => setIsNotificationOpen(!isNotificationOpen)}
      />

      <main className="container mx-auto px-6 py-6">
       {/* Search and Filters */}
<div className="flex items-center gap-3 mb-8">
  <button 
    className="flex items-center gap-3 px-5 py-2.5 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full shadow-sm hover:shadow-md transition-all text-gray-900 dark:text-white group active:scale-95"
    onClick={() => setIsFilterOpen(!isFilterOpen)}
  >
    <SlidersHorizontal className={`w-5 h-5 transition-colors ${
      (selectedCategories.length + selectedSemesters.length > 0) ? 'text-blue-500' : 'text-gray-500'
    }`} />
    <span className="text-base font-medium">Filters</span>
    
    {/* FILTER COUNTER BADGE */}
    {(selectedCategories.length + selectedSemesters.length > 0) && (
      <span className="flex h-5 w-5 items-center justify-center bg-blue-600 text-white text-[10px] font-bold rounded-full animate-in zoom-in duration-200">
        {selectedCategories.length + selectedSemesters.length}
      </span>
    )}
  </button>

  <div className="flex-1 relative max-w-lg">
    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
    <input
  type="text"
  placeholder="Search events..."
  value={searchQuery}
  onChange={(e) => setSearchQuery(e.target.value)}
  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
/>
  </div>
</div>

        {/* Event Sections */}
        <EventSection 
          title="Upcoming Events" 
          events={sortEventsByDate(filteredAllEvents)} 
          onEventClick={handleEventClick}
        />
        <EventSection 
          title="Popular Events" 
          events={filteredPopularEvents}
          onEventClick={handleEventClick}
        />
        <EventSection
          title="Newly Created Events"
          events={filteredMyEvents}
          onEventClick={handleEventClick}
          />
        {isLoggedIn && myEvents.length > 0 && (
          <EventSection 
            title="My Events" 
            count={myEvents.length}
            events={sortEventsByDate(filteredMyEvents)} 
            onEventClick={handleEventClick}
          />
        )}
        {isLoggedIn && attendingEvents.length > 0 && (
          <EventSection 
            title="Events I'm Attending" 
            count={attendingEvents.length}
            events={sortEventsByDate(filteredAttendingEvents)} 
            onEventClick={handleEventClick}
          />
        )}
      </main>

      {/* Event Modal */}
      <EventModal
        isOpen={isModalOpen}
        event={selectedEvent}
        onClose={() => setIsModalOpen(false)}
        canDelete={canDeleteSelectedEvent}
        onDelete={handleEventDelete}
        isLoggedIn={isLoggedIn}
      />

      {/* Login Modal */}
  
      {/* Filter Sidebar */}
      <FilterSidebar
  isOpen={isFilterOpen}
  onClose={() => setIsFilterOpen(false)}
  selectedCategories={selectedCategories}
  // Change this: use the setter from useFilters() directly
  onCategoryToggle={(category) => 
    setSelectedCategories(prev => 
      prev.includes(category) ? prev.filter(c => c !== category) : [...prev, category]
    )
  }
  // Change this: clear the array directly
  onShowAll={() => setSelectedCategories([])}
  selectedSemesters={selectedSemesters}
  // Change this: use the setter from useFilters() directly
  onSemesterToggle={(semester) => 
    setSelectedSemesters(prev => 
      prev.includes(semester) ? prev.filter(s => s !== semester) : [...prev, semester]
    )
  }
  // Change this: clear the array directly
  onShowAllSemesters={() => setSelectedSemesters([])}
/>
      {/* Notification Panel */}
      <NotificationPanel
        isOpen={isNotificationOpen}
        onClose={() => setIsNotificationOpen(false)}
        userSemester={userSemester}
        onNotificationDismiss={handleNotificationDismiss}
        dismissedNotifications={dismissedNotifications}
      />
    </div>
  );
}