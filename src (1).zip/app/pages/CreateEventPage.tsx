import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Link, useNavigate } from 'react-router';
import { ArrowLeft, Calendar, DollarSign, MapPin } from 'lucide-react';
import { addEvent } from '../utils/eventStorage';
import { LoginModal } from '../components/LoginModal';
import { useAuth } from '../contexts/AuthContext';


export function CreateEventPage() {
  const navigate = useNavigate();
  const { isLoggedIn, login, logout, isLoading } = useAuth();
  
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('isDarkMode');
    return saved === 'true';
  });
  
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const notificationCount = 1;

  // Form state
  const [eventTitle, setEventTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [organizer, setOrganizer] = useState('');
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [location, setLocation] = useState('');
  const [visibility, setVisibility] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [requestFinancialSupport, setRequestFinancialSupport] = useState(false);
  const [requestRoomBooking, setRequestRoomBooking] = useState(false);
  const [semester, setSemester] = useState('All');

  // Persist dark mode and apply classes
  useEffect(() => {
    localStorage.setItem('isDarkMode', String(isDarkMode));
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);
  // Persist login state to localStorage
  useEffect(() => {
    localStorage.setItem('isLoggedIn', String(isLoggedIn));
  }, [isLoggedIn]);

  // Persist dark mode to localStorage
  useEffect(() => {
    localStorage.setItem('isDarkMode', String(isDarkMode));
  }, [isDarkMode]);

  // Apply dark mode to document
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Add the event to storage
    addEvent({
      title: eventTitle,
      description,
      category,
      organizer,
      date,
      startTime,
      endTime,
      location,
      visibility,
      imageUrl: imageUrl || 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400&h=300&fit=crop', // Default image if none provided
      semester,
    });
    
    // Dispatch custom event to notify other components
    window.dispatchEvent(new Event('eventCreated'));
    
    // Navigate to events page
    navigate('/events');
  };

  const handleCancel = () => {
    // Reset form or navigate away
    window.history.back();
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <Header
        isLoggedIn={isLoggedIn}
        onLogin={login}
        onLogout={logout}
        isDarkMode={isDarkMode}
        onThemeToggle={() => setIsDarkMode(!isDarkMode)}
        notificationCount={notificationCount}
        activePage="create-event"
      />

      <main className="container mx-auto px-6 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Back to Events */}
          <Link to="/events" className="inline-flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Events</span>
          </Link>

          {/* Page Title */}
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-teal-600 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Create Event</h1>
          </div>
          <p className="text-gray-600 dark:text-gray-400 mb-8">Fill in the details to create a new event</p>

          {/* Show login prompt if not logged in */}
          {!isLoggedIn ? (
            <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 p-12 text-center">
              <div className="w-16 h-16 bg-teal-100 dark:bg-teal-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-teal-600 dark:text-teal-400" />
              </div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Login Required</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6">You need to be logged in to create an event</p>
              <button
                onClick={() => setIsLoginModalOpen(true)}
                className="px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white font-medium rounded-lg transition-colors"
              >
                Login to Continue
              </button>
            </div>
          ) : (
            /* Event Details Form */
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Event Details Section */}
              <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 p-6">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">Event Details</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">Provide information about your event to help students find and join it</p>

                {/* Event Title */}
                <div className="mb-4">
                  <label htmlFor="eventTitle" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Event Title <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="eventTitle"
                    value={eventTitle}
                    onChange={(e) => setEventTitle(e.target.value)}
                    placeholder="e.g., Spring Music Festival"
                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                    required
                  />
                </div>

                {/* Description */}
                <div className="mb-4">
                  <label htmlFor="description" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Description
                  </label>
                  <textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe your event..."
                    rows={4}
                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent resize-none"
                  />
                </div>

                {/* Category and Organizer */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="category" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                      Category <span className="text-red-500">*</span>
                    </label>
                    <select
                      id="category"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent appearance-none"
                      required
                    >
                      <option value="">Select category</option>
                      <option value="music">Music</option>
                      <option value="sports">Sports</option>
                      <option value="academic">Academic</option>
                      <option value="social">Social</option>
                      <option value="cultural">Cultural</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="organizer" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                      Organizer
                    </label>
                    <input
                      type="text"
                      id="organizer"
                      value={organizer}
                      onChange={(e) => setOrganizer(e.target.value)}
                      placeholder="e.g., Music Club"
                      className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                    />
                  </div>
                </div>

                {/* Date */}
                <div className="mb-4">
                  <label htmlFor="date" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    id="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                    required
                  />
                </div>

                {/* Start Time and End Time */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="startTime" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                      Start Time <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="time"
                      id="startTime"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="endTime" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                      End Time
                    </label>
                    <input
                      type="time"
                      id="endTime"
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                    />
                  </div>
                </div>

                {/* Location */}
                <div className="mb-4">
                  <label htmlFor="location" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Location
                  </label>
                  <input
                    type="text"
                    id="location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g., Main Auditorium"
                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  />
                </div>

                {/* Visibility */}
                <div className="mb-4">
                  <label htmlFor="visibility" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Visibility
                  </label>
                  <select
                    id="visibility"
                    value={visibility}
                    onChange={(e) => setVisibility(e.target.value)}
                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent appearance-none"
                  >
                    <option value="">Select who can see this event</option>
                    <option value="public">Public - Everyone can see</option>
                    <option value="students">Students Only</option>
                    <option value="private">Private - Invite Only</option>
                  </select>
                </div>

                {/* Target Semester */}
                <div className="mb-4">
                  <label htmlFor="semester" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Target Semester
                  </label>
                  <select
                    id="semester"
                    value={semester}
                    onChange={(e) => setSemester(e.target.value)}
                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent appearance-none"
                  >
                    <option value="All">All Semesters (Open to All)</option>
                    <option value="1st Semester">1st Semester</option>
                    <option value="2nd Semester">2nd Semester</option>
                    <option value="3rd Semester">3rd Semester</option>
                    <option value="4th Semester">4th Semester</option>
                    <option value="5th Semester">5th Semester</option>
                    <option value="6th Semester">6th Semester</option>
                    <option value="7th Semester">7th Semester</option>
                    <option value="8th Semester">8th Semester</option>
                  </select>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Everyone can see all events, but this helps students filter events relevant to their semester
                  </p>
                </div>

                {/* Event Image URL */}
                <div>
                  <label htmlFor="imageUrl" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Event Image URL (optional)
                  </label>
                  <input
                    type="url"
                    id="imageUrl"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="https://example.com/image.jpg"
                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Enter a URL to an image that represents your event</p>
                </div>

                {/* Divider */}
                <div className="flex items-center gap-4 my-4">
                  <div className="flex-1 h-px bg-gray-200 dark:bg-gray-800"></div>
                  <span className="text-sm text-gray-500 dark:text-gray-400">or</span>
                  <div className="flex-1 h-px bg-gray-200 dark:bg-gray-800"></div>
                </div>

                {/* Upload Image from PC */}
                <div>
                  <label htmlFor="imageFile" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                    Upload Event Image from PC (optional)
                  </label>
                  <div className="relative">
                    <input
                      type="file"
                      id="imageFile"
                      accept="image/*"
                      onChange={(e) => setImageFile(e.target.files?.[0] || null)}
                      className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-teal-50 file:text-teal-700 hover:file:bg-teal-100 dark:file:bg-teal-900/30 dark:file:text-teal-400 dark:hover:file:bg-teal-900/50 file:cursor-pointer focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                    />
                  </div>
                  {imageFile && (
                    <p className="text-xs text-teal-600 dark:text-teal-400 mt-1">
                      Selected: {imageFile.name}
                    </p>
                  )}
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Choose an image file from your computer (JPG, PNG, GIF, etc.)
                  </p>
                </div>

                {/* Buttons */}
                <div className="flex items-center gap-3 mt-6">
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-teal-600 hover:bg-teal-700 text-white font-medium rounded-lg transition-colors"
                  >
                    Create Event
                  </button>
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="px-8 py-3 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-900 dark:text-white font-medium rounded-lg border border-gray-300 dark:border-gray-600 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>

              {/* Financial Support Section */}
              <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                    <DollarSign className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-1">Financial Support (Optional)</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Request financial support for your event</p>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={requestFinancialSupport}
                        onChange={(e) => setRequestFinancialSupport(e.target.checked)}
                        className="w-4 h-4 rounded border-gray-300 dark:border-gray-600 text-teal-600 focus:ring-teal-500"
                      />
                      <span className="text-sm text-gray-900 dark:text-white">Request financial support for this event</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Room Booking Section */}
              <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-1">Room Booking (Optional)</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Request a room for your event</p>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={requestRoomBooking}
                        onChange={(e) => setRequestRoomBooking(e.target.checked)}
                        className="w-4 h-4 rounded border-gray-300 dark:border-gray-600 text-teal-600 focus:ring-teal-500"
                      />
                      <span className="text-sm text-gray-900 dark:text-white">Request a room booking for this event</span>
                    </label>
                  </div>
                </div>
              </div>
            </form>
          )}
        </div>
      </main>

     
    </div>
  );
}