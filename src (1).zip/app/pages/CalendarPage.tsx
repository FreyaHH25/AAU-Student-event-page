import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { LoginModal } from '../components/LoginModal';
import { useAuth } from '../contexts/AuthContext';
import { FilterSidebar } from '../components/FilterSidebar';
import { NotificationPanel } from '../components/NotificationPanel';
import { useFilters } from '../contexts/FilterContext';
import { 
  Calendar, 
  ChevronLeft, 
  ChevronRight, 
  SlidersHorizontal, 
  Search, 
  X, 
  Clock, 
  MapPin,
  Users,
  User,
  Tag 
} from 'lucide-react';
import { 
  getEvents, 
  Event, 
  toggleAttending, 
  isAttending 
} from '../utils/eventStorage';

// Updated Component to match EventsPage layout
function EventDetailPanel({ event, onClose, isLoggedIn }: { event: any, onClose: () => void, isLoggedIn: boolean }) {
  if (!event) return null;

  // State to handle the local toggle UI
  const [attending, setAttending] = useState(isAttending(event.id));

  // 1. ADD THIS: Local state for the attendee count
  const [displayCount, setDisplayCount] = useState(event.attendees || 0);

 // 2. UPDATE THIS: Keep the count in sync if the user clicks a different event
  useEffect(() => {
    setAttending(isAttending(event.id));
    setDisplayCount(event.attendees || 0);
  }, [event.id, event.attendees]);

  const handleToggleAttending = () => {
  if (!isLoggedIn) {
    alert("Please log in to attend events");
    return;
  }
  
  // 1. Determine the NEW state (before we toggle)
  const isNowAttending = !attending;

  // 2. Update the actual storage
  toggleAttending(event.id);
  
  // 3. Update the button text (Stop Attending / Attend Event)
  setAttending(isNowAttending);
  
  // 4. Update the "Students" count in the UI immediately
  // This is the fix you need:
  setDisplayCount(prev => isNowAttending ? prev + 1 : prev - 1);
  
  // 5. Signal the Calendar background to refresh its data
  window.dispatchEvent(new CustomEvent('attendingChanged'));
};

  return (
    <>
      <div 
        className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 lg:hidden" 
        onClick={onClose} 
      />
      
      <div className="fixed inset-y-0 right-0 w-full max-w-md bg-white dark:bg-gray-900 shadow-2xl z-50 border-l border-gray-200 dark:border-gray-800 flex flex-col animate-in slide-in-from-right duration-300">
        
        {/* Header Image Section */}
        <div className="relative h-64 w-full">
          <img 
            src={event.imageUrl || event.image} 
            className="w-full h-full object-cover" 
            alt={event.title} 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
          <button 
            onClick={onClose} 
            className="absolute top-4 right-4 p-2 bg-black/20 hover:bg-black/40 backdrop-blur-md text-white rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="absolute bottom-4 left-6 right-6">
            <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${event.categoryColor || 'bg-blue-100 text-blue-700'}`}>
              {event.category}
            </span>
            <h2 className="text-2xl font-bold text-white mt-2 leading-tight">
              {event.title}
            </h2>
          </div>
        </div>

        {/* Content Section */}
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-gray-100 dark:border-gray-700">
              <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 mb-1">
                <Users className="w-4 h-4" />
                <span className="text-[10px] font-semibold uppercase tracking-wider">Attending</span>
              </div>
              <p className="text-lg font-bold dark:text-white">{displayCount} Students</p>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-gray-100 dark:border-gray-700">
              <div className="flex items-center gap-2 text-purple-600 dark:text-purple-400 mb-1">
                <Tag className="w-4 h-4" />
                <span className="text-[10px] font-semibold uppercase tracking-wider">Semester</span>
              </div>
              <p className="text-lg font-bold dark:text-white">{event.semester || 'All'}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-4 p-2">
              <div className="p-2 bg-blue-50 dark:bg-blue-900/30 rounded-lg text-blue-600 dark:text-blue-400">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-medium text-gray-500 dark:text-gray-400">Date</p>
                <p className="font-semibold dark:text-white">{event.date}</p>
              </div>
            </div>
            <div className="flex items-start gap-4 p-2">
              <div className="p-2 bg-amber-50 dark:bg-amber-900/30 rounded-lg text-amber-600 dark:text-amber-400">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-medium text-gray-500 dark:text-gray-400">Time</p>
                <p className="font-semibold dark:text-white">{event.startTime} - {event.endTime}</p>
              </div>
            </div>
            <div className="flex items-start gap-4 p-2">
              <div className="p-2 bg-emerald-50 dark:bg-emerald-900/30 rounded-lg text-emerald-600 dark:text-emerald-400">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-medium text-gray-500 dark:text-gray-400">Location</p>
                <p className="font-semibold dark:text-white">{event.location}</p>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-gray-100 dark:border-gray-800">
            <h4 className="text-xs font-bold text-gray-900 dark:text-white uppercase tracking-widest mb-3">About this event</h4>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed text-sm">
              {event.description}
            </p>
          </div>
        </div>

        {/* Action Button: Matches the logic in EventsPage */}
        <div className="p-6 border-t border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50">
          <button 
            onClick={handleToggleAttending}
            className={`w-full py-4 rounded-2xl font-bold shadow-lg transition-all flex items-center justify-center gap-2 group ${
              attending 
                ? 'bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-900/20 dark:text-red-400 border border-red-100 dark:border-red-900/30 shadow-none' 
                : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-200 dark:shadow-none'
            }`}
          >
            {attending ? 'Stop Attending' : 'Attend Event'}
            {!attending && <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />}
          </button>
        </div>
      </div>
    </>
  );
}
export function CalendarPage() {
  const { isLoggedIn, login, logout } = useAuth();

  const [isDarkMode, setIsDarkMode] = useState(() => {
    // Initialize from localStorage
    const saved = localStorage.getItem('isDarkMode');
    return saved === 'true';
  });
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'monthly' | 'weekly'>('monthly');
  const [currentDate, setCurrentDate] = useState(new Date(2026, 2, 20)); // March 20, 2026
  const [hoveredDate, setHoveredDate] = useState<number | null>(null);
  const notificationCount = 1;

  // Sidebar & Filter States
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [selectedEventForPanel, setSelectedEventForPanel] = useState<any | null>(null);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
 const { 
  searchQuery, 
  setSearchQuery, 
  selectedCategories, 
  setSelectedCategories, 
  selectedSemesters, 
  setSelectedSemesters 
} = useFilters();

  
  const [dismissedNotifications, setDismissedNotifications] = useState<string[]>(() => {
    const saved = localStorage.getItem('dismissedNotifications');
    return saved ? JSON.parse(saved) : [];
  });

  const [userSemester] = useState(() => {
    const saved = localStorage.getItem('userSemester');
    return saved || '3rd Semester';
  });

  // Load events from storage
  const [userEvents, setUserEvents] = useState<Event[]>([]);

  // Persist login state to localStorage
  useEffect(() => {
    localStorage.setItem('isLoggedIn', String(isLoggedIn));
  }, [isLoggedIn]);

  // Persist dark mode to localStorage
  useEffect(() => {
    localStorage.setItem('isDarkMode', String(isDarkMode));
  }, [isDarkMode]);

  useEffect(() => {
    const loadEvents = () => {
      const events = getEvents();
      setUserEvents(events);
    };
    
    loadEvents();
    
    // Listen for custom event when new event is created
    const handleEventCreated = () => {
      loadEvents();
    };
    
    window.addEventListener('eventCreated', handleEventCreated);
    
    return () => {
      window.removeEventListener('eventCreated', handleEventCreated);
    };
  }, []);

  // Apply dark mode to document
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Sample events (from original design) - matching EventsPage
  const sampleEvents: Event[] = [
    {
      id: '1',
      title: 'Study Group - Finals Preparation',
      description: 'Join fellow students for collaborative studying and exam preparation',
      category: 'Workshop',
      organizer: 'Academic Success Center',
      date: '2026-03-15',
      startTime: '19:00',
      endTime: '21:00',
      location: 'University Library, Room 302',
      visibility: 'public',
      imageUrl: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=300&fit=crop',
      attendees: 24,
      categoryColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      semester: 'All'
    },
    {
      id: '4',
      title: 'Resume Writing Workshop',
      description: 'Learn how to craft an impressive resume and cover letter',
      category: 'Workshop',
      organizer: 'Career Services',
      date: '2026-03-27',
      startTime: '16:00',
      endTime: '18:00',
      location: 'Career Center, Suite 200',
      visibility: 'public',
      imageUrl: 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=400&h=300&fit=crop',
      attendees: 18,
      categoryColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      semester: '3rd Semester'
    },
    {
      id: '5',
      title: 'Basketball Tournament Finals',
      description: 'Championship game of the annual intramural basketball tournament',
      category: 'Sports',
      organizer: 'Athletics Department',
      date: '2026-03-29',
      startTime: '19:00',
      endTime: '21:00',
      location: 'Recreation Center',
      visibility: 'public',
      imageUrl: 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=400&h=300&fit=crop',
      attendees: 100,
      categoryColor: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
      semester: 'All'
    },
    {
      id: '6',
      title: 'Guest Lecture: AI in Healthcare',
      description: 'Renowned researcher discusses applications of AI in medical diagnostics',
      category: 'Academic',
      organizer: 'Computer Science Department',
      date: '2026-04-02',
      startTime: '15:00',
      endTime: '17:00',
      location: 'Science Building, Auditorium A',
      visibility: 'public',
      imageUrl: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400&h=300&fit=crop',
      attendees: 89,
      categoryColor: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
      semester: '5th Semester'
    },
    {
      id: '7',
      title: 'International Food Festival',
      description: 'Celebrate global cultures with authentic cuisines from around the world',
      category: 'Social',
      organizer: 'International Student Association',
      date: '2026-04-06',
      startTime: '12:00',
      endTime: '18:00',
      location: 'Student Union Plaza',
      visibility: 'public',
      imageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&h=300&fit=crop',
      attendees: 245,
      categoryColor: 'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300',
      semester: 'All'
    },
    {
      id: '8',
      title: 'Photography Basics Workshop',
      description: 'Hands-on introduction to photography techniques and composition',
      category: 'Workshop',
      organizer: 'Photography Club',
      date: '2026-04-11',
      startTime: '17:00',
      endTime: '19:00',
      location: 'Arts Building, Studio 5',
      visibility: 'public',
      imageUrl: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=400&h=300&fit=crop',
      attendees: 22,
      categoryColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      semester: '1st Semester'
    },
    {
      id: '2',
      title: 'Engineering Club Meeting',
      description: 'Monthly meeting to discuss upcoming projects and research collaboration',
      category: 'Conference',
      organizer: 'Engineering Society',
      date: '2026-04-12',
      startTime: '18:00',
      endTime: '20:00',
      location: 'Engineering Building, LAB 18',
      visibility: 'public',
      imageUrl: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=400&h=300&fit=crop',
      attendees: 45,
      categoryColor: 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300',
      semester: '2nd Semester'
    },
    {
      id: '3',
      title: 'Spring Festival 2026',
      description: 'Annual spring celebration with food, music, and entertainment',
      category: 'Social',
      organizer: 'Student Activities Board',
      date: '2026-04-20',
      startTime: '14:00',
      endTime: '22:00',
      location: 'Main Campus Quad',
      visibility: 'public',
      imageUrl: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=400&h=300&fit=crop',
      attendees: 320,
      categoryColor: 'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300',
      semester: 'All'
    },
    {
      id: '11',
      image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop',
      category: 'Workshop',
      title: 'UI/UX Design Sprint',
      description: 'A fast-paced workshop on prototyping user interfaces using modern design tools.',
      date: '2026-03-25',
      startTime: '10:00',
      endTime: '13:00',
      location: 'Design Lab, Room 104',
      attendees: 15,
      organizer: 'Digital Arts Collective',
      categoryColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      semester: 'All'
    },
    {
      id: '12',
      image: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?w=400&h=300&fit=crop',
      category: 'Sports',
      title: 'Mid-Week Yoga Flow',
      description: 'De-stress with a guided yoga session open to all skill levels.',
      date: '2026-03-25',
      startTime: '08:00',
      endTime: '09:00',
      location: 'South Campus Lawn',
      attendees: 42,
      organizer: 'Wellness Center',
      categoryColor: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
      semester: 'All'
    },
    {
      id: '13',
      image: 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=400&h=300&fit=crop',
      category: 'Academic',
      title: 'Sustainability Symposium',
      description: 'Discussing renewable energy initiatives within the university infrastructure.',
      date: '2026-03-25',
      startTime: '14:00',
      endTime: '16:30',
      location: 'Green Hall, Auditorium C',
      attendees: 120,
      organizer: 'Environmental Society',
      categoryColor: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
      semester: 'All'
    },
    {
      id: '14',
      image: 'https://images.unsplash.com/photo-1528605248644-14dd04022da1?w=400&h=300&fit=crop',
      category: 'Social',
      title: 'Board Game Night',
      description: 'Pizza, tabletop games, and networking with fellow students.',
      date: '2026-03-25',
      startTime: '18:00',
      endTime: '21:00',
      location: 'Student Lounge',
      attendees: 55,
      organizer: 'Gaming Club',
      categoryColor: 'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300',
      semester: '1st Semester'
    },
    {
      id: '15',
      image: 'https://images.unsplash.com/photo-1431540015161-0bf868a2d407?w=400&h=300&fit=crop',
      category: 'Conference',
      title: 'Startup Networking Mixer',
      description: 'Connect with local entrepreneurs and discuss internship opportunities.',
      date: '2026-03-25',
      startTime: '17:00',
      endTime: '19:00',
      location: 'Innovation Hub',
      attendees: 85,
      organizer: 'Business School',
      categoryColor: 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300',
      semester: 'All'
    }
    
  ];

  // Combine sample events with user-created events
  const allEvents = [...sampleEvents, ...userEvents];

const filteredEvents = allEvents.filter(event => {
  // Søge-filter
  const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                        event.description.toLowerCase().includes(searchQuery.toLowerCase());
  
  // Kategori-filter (vi gør begge små bogstaver for at være sikre på match)
  const categoryMatch = selectedCategories.length === 0 || 
    selectedCategories.some(cat => cat.toLowerCase() === event.category.toLowerCase());

  // Semester-filter
  const eventSemester = event.semester || 'All';
  const semesterMatch = selectedSemesters.length === 0 || 
    selectedSemesters.includes(eventSemester);

  return matchesSearch && categoryMatch && semesterMatch;
});

  
  // Helper functions - define before use
  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    
    return { daysInMonth, startingDayOfWeek, year, month };
  };

  const getWeekRange = (date: Date) => {
    const dayOfWeek = date.getDay();
    const startOfWeek = new Date(date);
    startOfWeek.setDate(date.getDate() - dayOfWeek);
    startOfWeek.setHours(0, 0, 0, 0); // Set to midnight
    
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999); // Set to end of day
    
    return { startOfWeek, endOfWeek };
  };

  // Get dates that have events for the current month
  const getEventsOnDates = () => {
    const monthEvents = filteredEvents.filter(event => {
      const eventDate = new Date(event.date);
      return eventDate.getMonth() === currentDate.getMonth() && 
             eventDate.getFullYear() === currentDate.getFullYear();
    });
    
    return monthEvents.map(event => new Date(event.date).getDate());
  };

  const eventsOnDates = getEventsOnDates();

  // Get weekly events for the weekly view
  const getWeeklyEvents = () => {
    const { startOfWeek, endOfWeek } = getWeekRange(currentDate);
    
    return filteredEvents
        .filter(event => {
        const eventDate = new Date(event.date);
        return eventDate >= startOfWeek && eventDate <= endOfWeek;
      })
      .map(event => {
        const eventDate = new Date(event.date);
        const [hours] = event.startTime.split(':').map(Number);
        const duration = event.endTime ? 
          (parseInt(event.endTime.split(':')[0]) - parseInt(event.startTime.split(':')[0])) : 
          1;
        
        // Map category to color
        const colorMap: { [key: string]: string } = {
          music: 'bg-pink-500',
          sports: 'bg-orange-500',
          academic: 'bg-blue-500',
          social: 'bg-pink-500',
          cultural: 'bg-teal-500',
          workshop: 'bg-purple-500',
          conference: 'bg-teal-500',
        };
        
        return {
          id: event.id,
          title: event.title,
          day: eventDate.getDay(),
          dateNumber: eventDate.getDate(), // Add the actual date number
          startHour: hours,
          duration,
          color: colorMap[event.category.toLowerCase()] || 'bg-gray-500'
        };
      });
  };

  const weeklyEvents = getWeeklyEvents();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const { daysInMonth, startingDayOfWeek, year, month } = getDaysInMonth(currentDate);

  const goToPreviousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const goToNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date(2026, 2, 20)); // March 20, 2026
  };

  const goToPreviousWeek = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() - 7);
    setCurrentDate(newDate);
  };

  const goToNextWeek = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() + 7);
    setCurrentDate(newDate);
  };

  const { startOfWeek, endOfWeek } = getWeekRange(currentDate);
  
  const getWeekDays = () => {
    const days = [];
    for (let i = 0; i < 7; i++) {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + i);
      days.push(day);
    }
    return days;
  };

  const timeSlots = Array.from({ length: 24 }, (_, i) => i); // 0:00 to 23:00 (full 24 hours)

  const formatWeekRange = () => {
    const monthStart = monthNames[startOfWeek.getMonth()].slice(0, 3);
    const monthEnd = monthNames[endOfWeek.getMonth()].slice(0, 3);
    return `${monthStart} ${startOfWeek.getDate()} - ${monthEnd} ${endOfWeek.getDate()}, ${endOfWeek.getFullYear()}`;
  };

const getCategoryColor = (category: string) => {
  const colors: Record<string, string> = {
    // Your existing 7 colors
    sports: 'bg-emerald-500',
    academic: 'bg-blue-500',
    social: 'bg-pink-500',
    wellness: 'bg-cyan-500',
    workshop: 'bg-purple-500',
    career: 'bg-amber-500',
    conference: 'bg-teal-500',
    
    // Added 3 to reach 10 total
    music: 'bg-rose-500',
    club: 'bg-indigo-500',
    volunteer: 'bg-orange-500',
  };
  
  return colors[category.toLowerCase()] || 'bg-gray-400';
};
  const renderCalendarDays = () => {
    const days = [];
    const today = 18; // March 18, 2026
    
    // 1. Previous month's trailing days
    const prevMonthDays = new Date(year, month, 0).getDate();
    for (let i = startingDayOfWeek - 1; i >= 0; i--) {
      days.push(
        <div key={`prev-${i}`} className="min-h-[120px] p-2 border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50">
          <span className="text-sm text-gray-400 dark:text-gray-600">{prevMonthDays - i}</span>
        </div>
      );
    }

    // 2. Current month's days with Event Logic
    for (let day = 1; day <= daysInMonth; day++) {
      const isToday = day === today;
      const isHovered = hoveredDate === day;
      
      // Filter events specifically for this day
     const rawDayEvents = filteredEvents.filter(event => {
  const eventDate = new Date(event.date);
  return eventDate.getDate() === day && 
         eventDate.getMonth() === month && 
         eventDate.getFullYear() === year;
});

      const dayEvents = rawDayEvents
  .sort((a, b) => Number(a.id) - Number(b.id)) 
  .slice(-5)                                  
  .reverse();

      days.push(
        <div 
          key={day} 
          className={`relative min-h-[120px] p-2 border transition-all cursor-pointer group ${
            dayEvents.length > 0 ? 'border-blue-200 dark:border-blue-900/30' : 'border-gray-200 dark:border-gray-800'
          } ${
            isToday ? 'bg-blue-50/50 dark:bg-blue-900/20' : 'bg-white dark:bg-gray-900'
          } ${
            isHovered ? 'ring-2 ring-blue-500 ring-inset z-10' : ''
          }`}
          onMouseEnter={() => setHoveredDate(day)}
          onMouseLeave={() => setHoveredDate(null)}
          onClick={() => {
            setCurrentDate(new Date(year, month, day));
            setViewMode('weekly');
          }}
        >
          {/* Day Number Header */}
          <div className="flex justify-between items-start mb-1">
            <span className={`inline-flex items-center justify-center w-7 h-7 text-sm font-semibold ${
              isToday ? 'bg-blue-600 text-white rounded-full' : 'text-gray-900 dark:text-white'
            }`}>
              {day}
            </span>
          </div>
          
      {/* Event List Container */}
<div className="space-y-1 mt-1 overflow-hidden">
  {dayEvents.map((event) => {
    const catColorClass = getCategoryColor(event.category);
    return (
      <div 
        key={event.id} 
        onClick={(e) => {
          e.stopPropagation();
          setSelectedEventForPanel(event);
        }}
        className="flex items-center gap-1 px-1 py-0.5 rounded text-[9px] font-medium truncate bg-gray-100/80 dark:bg-gray-800/80 text-gray-700 dark:text-gray-300 border-l-2 border-blue-500 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
        style={{ borderLeftColor: 'currentColor' }} // Fallback to CSS or use specific hex if available
      >
        <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${catColorClass}`} />
        <span className="truncate">{event.title}</span>
      </div>
    );
  })}

  {rawDayEvents.length > 5 && (
    <div className="text-[9px] text-blue-600 dark:text-blue-400 font-bold pl-1 pt-0.5">
      + {rawDayEvents.length - 5} more
    </div>
  )}
</div>
        </div>
      );
    }

    // 3. Next month's leading days
    const totalCells = days.length;
    const remainingCells = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
    for (let day = 1; day <= remainingCells; day++) {
      days.push(
        <div key={`next-${day}`} className="min-h-[120px] p-2 border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50">
          <span className="text-sm text-gray-400 dark:text-gray-600">{day}</span>
        </div>
      );
    }

    return days;
  };
 


  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <Header
        isLoggedIn={isLoggedIn}
        onLoginClick={() => setIsLoginModalOpen(true)}
        onLogout={logout}
        isDarkMode={isDarkMode}
        onThemeToggle={() => setIsDarkMode(!isDarkMode)}
        notificationCount={notificationCount}
        activePage="calendar"
      />

      <main className="container mx-auto px-6 py-8">
{/* Page Title & Filter Button */}
<div className="mb-8 space-y-6">
  <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Calendar</h1>

  <div className="flex items-center gap-3">
    {/* Filter Button */}
    <button 
      onClick={() => setIsFilterOpen(true)}
      className="flex items-center gap-3 px-5 py-2.5 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full shadow-sm hover:shadow-md transition-all text-gray-900 dark:text-white active:scale-95"
    >
      <SlidersHorizontal className={`w-5 h-5 ${(selectedCategories.length + selectedSemesters.length > 0) ? 'text-blue-500' : 'text-gray-500'}`} />
      <span className="text-base font-medium">Filters</span>
      {(selectedCategories.length + selectedSemesters.length > 0) && (
        <span className="flex h-5 w-5 items-center justify-center bg-blue-600 text-white text-[10px] font-bold rounded-full">
          {selectedCategories.length + selectedSemesters.length}
        </span>
      )}
    </button>

    {/* Search Input - PASTE HERE */}
    <div className="flex-1 relative max-w-lg">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
      <input
        type="text"
        placeholder="Search events..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
      />
    </div>
  </div>
</div>

        {/* View Toggle & Filters Container */}
<div className="flex flex-wrap items-center justify-between gap-4 mb-8">
  {/* Venstre side: View knapper */}
  <div className="flex items-center gap-3">
    <button
      onClick={() => setViewMode('monthly')}
      className={`flex items-center gap-2 px-5 py-2.5 rounded-lg border transition-colors ${
        viewMode === 'monthly'
          ? 'bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm'
          : 'bg-transparent border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
      }`}
    >
      <Calendar className="w-4 h-4" />
      <span>Monthly View</span>
    </button>
    
    <button
      onClick={() => setViewMode('weekly')}
      className={`flex items-center gap-2 px-5 py-2.5 rounded-lg border transition-colors ${
        viewMode === 'weekly'
          ? 'bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm'
          : 'bg-transparent border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
      }`}
    >
      <Calendar className="w-4 h-4" />
      <span>Weekly View</span>
    </button>
  </div>

 
</div>

       
        {/* Calendar */}
        <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 p-6">
          {viewMode === 'monthly' ? (
            <>
              {/* Monthly View - Calendar Header */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {monthNames[month]} {year}
                </h2>
                <div className="flex items-center gap-4">
                  {/* Hovered Date Display */}
                  {hoveredDate !== null ? (
                    <span className="text-sm font-medium text-blue-600 dark:text-blue-400 min-w-[100px]">
                      March {hoveredDate}
                    </span>
                  ) : (
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400 min-w-[100px]">
                      Today: March 18
                    </span>
                  )}
                  
                  <div className="flex items-center gap-2">
                    <button
                      onClick={goToPreviousMonth}
                      className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                      aria-label="Previous month"
                    >
                      <ChevronLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                    </button>
                    <button
                      onClick={goToToday}
                      className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                    >
                      Today
                    </button>
                    <button
                      onClick={goToNextMonth}
                      className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                      aria-label="Next month"
                    >
                      <ChevronRight className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Day Names */}
              <div className="grid grid-cols-7 mb-2">
                {dayNames.map((day) => (
                  <div key={day} className="text-center py-3 text-sm font-medium text-gray-600 dark:text-gray-400">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7">
                {renderCalendarDays()}
              </div>
            </>
          ) : (
            <>
              {/* Weekly View - Calendar Header */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                  {formatWeekRange()}
                </h2>
                <div className="flex items-center gap-2">
                  <button
                    onClick={goToPreviousWeek}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                    aria-label="Previous week"
                  >
                    <ChevronLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </button>
                  <button
                    onClick={goToToday}
                    className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                  >
                    This Week
                  </button>
                  <button
                    onClick={goToNextWeek}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                    aria-label="Next week"
                  >
                    <ChevronRight className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </button>
                </div>
              </div>

              {/* Weekly Grid */}
              <div className="overflow-x-auto">
                <div className="grid grid-cols-8 min-w-[900px]">
                  {/* Time column header */}
                  <div className="border-b border-gray-200 dark:border-gray-800 p-3"></div>
                  
                  {/* Day headers */}
                  {getWeekDays().map((day, index) => {
                    const isToday = day.getDate() === 18 && day.getMonth() === 2;
                    return (
                      <div key={index} className="border-b border-gray-200 dark:border-gray-800 p-3 text-center">
                        <div className="text-xs text-gray-600 dark:text-gray-400 mb-1">
                          {dayNames[day.getDay()]}
                        </div>
                        <div className={`inline-flex items-center justify-center w-8 h-8 text-sm font-medium ${
                          isToday 
                            ? 'bg-blue-600 text-white rounded-full' 
                            : 'text-gray-900 dark:text-white'
                        }`}>
                          {day.getDate()}
                        </div>
                      </div>
                    );
                  })}

                  {/* Time slots and event grid */}
                  {timeSlots.map((hour) => (
                    <>
                      {/* Time label */}
                      <div key={`time-${hour}`} className="border-r border-b border-gray-200 dark:border-gray-800 p-3 text-sm text-gray-600 dark:text-gray-400" style={{ height: '60px' }}>
                        {hour.toString().padStart(2, '0')}:00
                      </div>
                      
                      {/* Day cells */}
                      {getWeekDays().map((day, dayIndex) => {
                        const event = weeklyEvents.find(
                          e => e.dateNumber === day.getDate() && e.startHour === hour
                        );
                        
                        return (
                          <div 
                            key={`${dayIndex}-${hour}`} 
                            className="relative border-r border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-850 transition-colors"
                            style={{ height: '60px' }}
                          >
                            {event && (
                              <div 
  onClick={() => setSelectedEventForPanel(allEvents.find(e => e.id === event.id))}
  className={`absolute left-1 right-1 top-1 ${event.color} text-white rounded p-2 text-xs font-medium overflow-hidden cursor-pointer hover:brightness-110 shadow-md`}
                                style={{ 
                                  height: `${event.duration * 60 - 8}px`,
                                  zIndex: 10
                                }}
                              >
                                <div className="truncate font-semibold">{event.title}</div>
                                <div className="text-white/90 text-[10px] mt-0.5">
                                  {event.startHour.toString().padStart(2, '0')}:00 - {(event.startHour + event.duration).toString().padStart(2, '0')}:00
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
        {/* Modals & Overlays */}
      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)} 
      />

      <FilterSidebar
        isOpen={isFilterOpen}
        onClose={() => setIsFilterOpen(false)}
        selectedCategories={selectedCategories}
        onCategoryToggle={(category) => 
          setSelectedCategories(prev => 
            prev.includes(category) ? prev.filter(c => c !== category) : [...prev, category]
          )
        }
        onShowAll={() => setSelectedCategories([])}
        selectedSemesters={selectedSemesters}
        onSemesterToggle={(semester) => 
          setSelectedSemesters(prev => 
            prev.includes(semester) ? prev.filter(s => s !== semester) : [...prev, semester]
          )
        }
        onShowAllSemesters={() => setSelectedSemesters([])}
      />

      <NotificationPanel 
        isOpen={isNotificationOpen}
        onClose={() => setIsNotificationOpen(false)}
        notifications={[]} 
        dismissedNotifications={dismissedNotifications}
        setDismissedNotifications={setDismissedNotifications}
      /> 

      {selectedEventForPanel && (
        <EventDetailPanel 
          event={selectedEventForPanel} 
          onClose={() => setSelectedEventForPanel(null)} 
          isLoggedIn={isLoggedIn}
        />
      )}
    </main>
  </div>
);
}
       